unit CDMain;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, StdCtrls, jpeg, shellapi, ComCtrls;

type
  TForm1 = class(TForm)
    ImageBackground: TImage;
    TimerTitle: TTimer;
    LabelInfProc: TLabel;
    MemoCopyright: TMemo;
    LabelInstructions: TLabel;
    LabelWinisis: TLabel;
    LabelGenisis: TLabel;
    LabelXML: TLabel;
    LabelDataExchange: TLabel;
    LabelIDAMS: TLabel;
    LabelIDIS: TLabel;
    LabelC2003: TLabel;
    Label_IsisWeb: TLabel;
    Panel_IDAMS: TPanel;
    ImgIDAMS_ENG: TImage;
    LabelIDAMSEng: TLabel;
    Label15: TLabel;
    LabelIDAMSFre: TLabel;
    LabelIDAMSEsp: TLabel;
    Panel_GENISIS: TPanel;
    ImgGenisisWeb: TImage;
    LabelGenisisWeb: TLabel;
    LabelGenisisCD: TLabel;
    Panel_ISISDOC: TPanel;
    LabelGenisisWebUM: TLabel;
    LabelGenisisCDUM: TLabel;
    Image1: TImage;
    Panel_IDAMSDOC: TPanel;
    Label1: TLabel;
    Image2: TImage;
    Label_IDAMSDocEN: TLabel;
    Label_IDAMSDocFR: TLabel;
    Label_IDAMSDocES: TLabel;
    LabelIDIS2: TLabel;
    LabelIsisMarc: TLabel;
    LabelIsisMarc2: TLabel;
    Label_IDAMSDocOther: TLabel;
    Panel_DataEx: TPanel;
    Image3: TImage;
    Label2709: TLabel;
    LabelIsisAscii: TLabel;
    Memo1: TMemo;
    Panel_IDIS: TPanel;
    Label5: TLabel;
    LabelIDISExe: TLabel;
    LabelIDISGuide: TLabel;
    Image4: TImage;
    Panel_MARC: TPanel;
    Image5: TImage;
    Memo2: TMemo;
    LabelMarcInstall: TLabel;
    LabelMarcManual: TLabel;
    Label3: TLabel;
    Panel_Winisis: TPanel;
    ImgWinisis: TImage;
    Memo5: TMemo;
    LabelWinisis15: TLabel;
    LabelHandbookEN: TLabel;
    LabelWinisisNew: TLabel;
    ButtonAccept: TButton;
    ButtonDecline: TButton;
    Label7: TLabel;
    Label8: TLabel;
    Label11: TLabel;
    Label13: TLabel;
    LabelIsisGuideEN: TLabel;
    LabelNetworkEN: TLabel;
    LabelOtherIsisDoc: TLabel;
    LabelIsisDocFRE: TLabel;
    LabelIsisDocEsp: TLabel;
    LabelIsisDocRus: TLabel;
    LabelIsisDocCHI: TLabel;
    Memo3: TMemo;
    Bevel1: TBevel;
    Panel_XML: TPanel;
    Memo4: TMemo;
    Image6: TImage;
    Label_XML2Isis: TLabel;
    Label_Isis2XML: TLabel;
    Bevel2: TBevel;
    LabelJavaISIS: TLabel;
    Label4: TLabel;
    Memo6: TMemo;
    LabelIsisRM: TLabel;
    procedure GeneralMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure GeneralMouseMoveBlue(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure PanelMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure TimerTitleTimer(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure ImgXMLClick(Sender: TObject);
    procedure LabelIDIS2MouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure LabelGenisisClick(Sender: TObject);
    procedure LabelWinisisClick(Sender: TObject);
    procedure LabelXMLClick(Sender: TObject);
    procedure LabelIDAMSClick(Sender: TObject);
    procedure LabelDataExchangeClick(Sender: TObject);
    procedure LabelIDAMSDocClick(Sender: TObject);
    procedure LabelIsisMarc2MouseMove(Sender: TObject; Shift: TShiftState;
      X, Y: Integer);
    procedure LabelIsisDocClick(Sender: TObject);
    procedure Label_IsisWebClick(Sender: TObject);
    procedure ImageBackgroundMouseMove(Sender: TObject; Shift: TShiftState;
      X, Y: Integer);
    procedure Label_IDAMSDocOtherClick(Sender: TObject);
    procedure Label_IDAMSDocENClick(Sender: TObject);
    procedure Label_IDAMSDocFRClick(Sender: TObject);
    procedure Label_IDAMSDocESClick(Sender: TObject);
    procedure LabelIDAMSEngClick(Sender: TObject);
    procedure LabelIDAMSFreClick(Sender: TObject);
    procedure LabelIDAMSEspClick(Sender: TObject);
    procedure LabelIDISClick(Sender: TObject);
    procedure LabelIDISExeClick(Sender: TObject);
    procedure LabelIDISGuideClick(Sender: TObject);
    procedure LabelIsisMarcClick(Sender: TObject);
    procedure LabelMarcInstallClick(Sender: TObject);
    procedure LabelMarcManualClick(Sender: TObject);
    procedure LabelGenisisWebClick(Sender: TObject);
    procedure LabelGenisisCDClick(Sender: TObject);
    procedure LabelGenisisWebUMClick(Sender: TObject);
    procedure LabelGenisisCDUMClick(Sender: TObject);
    procedure Label2709Click(Sender: TObject);
    procedure LabelIsisAsciiClick(Sender: TObject);
    procedure LabelHandbookENClick(Sender: TObject);
    procedure LabelIsisGuideENClick(Sender: TObject);
    procedure LabelNetworkENClick(Sender: TObject);
    procedure LabelWinisisNewClick(Sender: TObject);
    procedure LabelIsisDocFREClick(Sender: TObject);
    procedure LabelIsisDocEspClick(Sender: TObject);
    procedure LabelIsisDocRusClick(Sender: TObject);
    procedure LabelIsisDocCHIClick(Sender: TObject);
    procedure LabelIsisMarc2Click(Sender: TObject);
    procedure LabelIDIS2Click(Sender: TObject);
    procedure LabelWinisis15Click(Sender: TObject);
    procedure ButtonAcceptClick(Sender: TObject);
    procedure ButtonDeclineClick(Sender: TObject);
    procedure WinisisMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure LabelJavaISISClick(Sender: TObject);
    procedure LabelIsisRMClick(Sender: TObject);
    procedure Label_XML2IsisClick(Sender: TObject);
    procedure Label_Isis2XMLClick(Sender: TObject);


  private
    { D�clarations priv�es }
  public
    { D�clarations publiques }
  end;

var
  Form1: TForm1;
  TimerTitleCount: integer;
  drv: string[255];
  filename: string[255];

implementation

{$R *.dfm}



procedure TForm1.TimerTitleTimer(Sender: TObject);
begin
LabelInfProc.Visible := true;
LabelC2003.visible := true;
Label_IsisWeb.Visible := true;
Case TimerTitleCount of
        1:      begin
                MemoCopyright.Visible := True;
                ButtonAccept.Visible:=true;
                ButtonDecline.Visible:=true;
                MemoCopyright.Top:=240;
                MemoCopyright.Left:=102;
                MemoCopyright.Height:=140;
                end;
        end;
Inc(TimerTitleCount);
end;


procedure TForm1.FormCreate(Sender: TObject);
begin
TimerTitleCount:=0;
Panel_XML.visible:=false;
Panel_IDAMS.visible:=false;
Panel_GENISIS.visible:=false;
Panel_IsisDOC.visible:=false;
Panel_IDAMSDOC.visible:=false;
Panel_DataEx.Visible:=false;
Panel_Idis.visible:=false;
Panel_MARC.Visible:=false;
Panel_Winisis.Visible:=false;
drv:=GetCurrentDir;

end;


procedure TForm1.ImgXMLClick(Sender: TObject);
begin
Panel_XML.Top:=184;
Panel_XML.Left:=8;
Panel_XML.Width:=281;
Panel_XML.height:=145;
Panel_XML.caption:='';
Panel_XML.visible:=true;
end;

procedure TForm1.LabelIDIS2MouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Integer);
begin
GeneralMouseMove(LabelIDIS2,Shift,X,Y);
GeneralMouseMove(LabelIDIS,Shift,X,Y);
end;

procedure TForm1.LabelWinisisClick(Sender: TObject);
begin
Panel_Winisis.Top:=104;
Panel_Winisis.Left:=0;
Panel_Winisis.Width:=369;
Panel_Winisis.height:=361;
Panel_Winisis.caption:='';
Panel_Winisis.visible:=true;
end;

procedure TForm1.LabelXMLClick(Sender: TObject);
begin
Panel_XML.Top:=288;
Panel_XML.Left:=16;
Panel_XML.Width:=297;
Panel_XML.height:=145;
Panel_XML.caption:='';
Panel_XML.visible:=true;
end;


procedure TForm1.LabelIDAMSClick(Sender: TObject);
begin
Panel_XML.visible:=false;

Panel_IDAMS.Top:=192;
Panel_IDAMS.Left:=312;
Panel_IDAMS.Width:=321;
Panel_IDAMS.height:=273;
Panel_IDAMS.caption:='';
Panel_IDAMS.visible:=true;
end;


procedure TForm1.LabelDataExchangeClick(Sender: TObject);
begin
Panel_DataEx.Top:=288;
Panel_DataEx.Left:=352;
Panel_DataEx.Width:=265;
Panel_DataEx.height:=137;
Panel_DataEx.caption:='';
Panel_DataEx.visible:=true;
end;

procedure TForm1.LabelIDAMSDocClick(Sender: TObject);
begin
Panel_IDAMSDOC.Top:=336;
Panel_IDAMSDOC.Left:=288;
Panel_IDAMSDOC.Width:=337;
Panel_IDAMSDOC.height:=137;
Panel_IDAMSDOC.caption:='';
Panel_IDAMSDOC.visible:=true;
end;

procedure TForm1.LabelIsisMarc2MouseMove(Sender: TObject;
  Shift: TShiftState; X, Y: Integer);
begin
GeneralMouseMove(LabelIsisMarc2,Shift,X,Y);
GeneralMouseMove(LabelIsisMarc,Shift,X,Y);
end;

procedure TForm1.GeneralMouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Integer);
begin
TLabel(Sender).Font.Color:=clWhite;
TLabel(Sender).Font.Style:=[fsUnderline];
Panel_XML.visible:=false;
Panel_IDAMS.visible:=false;
Panel_GENISIS.visible:=false;
Panel_IsisDOC.visible:=false;
Panel_IDAMSDOC.visible:=false;
Panel_DataEx.Visible:=false;
Panel_IDIS.Visible:=false;
Panel_MARC.Visible:=false;
Panel_Winisis.Visible:=false;
end;

procedure TForm1.LabelGenisisClick(Sender: TObject);
begin
Panel_Genisis.Top:=240;
Panel_Genisis.Left:=40;
Panel_Genisis.Width:=329;
Panel_Genisis.height:=161;
Panel_Genisis.caption:='';
Panel_Genisis.visible:=true;
end;

procedure TForm1.GeneralMouseMoveBlue(Sender: TObject; Shift: TShiftState;
  X, Y: Integer);
begin
// PanelMouseMove(Sender,Shift,X,Y);
TLabel(Sender).Font.Color:=clBlue;
TLabel(Sender).Font.Style:=[fsBold];
end;

procedure TForm1.LabelIsisDocClick(Sender: TObject);
begin
Panel_IsisDOC.Top:=240;
Panel_IsisDOC.Left:=8;
Panel_IsisDOC.Width:=425;
Panel_IsisDOC.height:=233;
Panel_IsisDOC.caption:='';
Panel_IsisDOC.visible:=true;
end;

procedure TForm1.PanelMouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Integer);
var
  I: Integer;
  ChildControl: TLabel;
begin
  for I:= 0 to TPanel(Sender).ControlCount -1 do
  begin
    ChildControl := TLabel(TPanel(Sender).Controls[I]);
    case ChildControl.HelpContext of
        0: begin
           ChildControl.Font.Style := [];
           ChildControl.Font.Color := clBlack;
           end;
        2 : begin
           ChildControl.Font.Style := [];
           ChildControl.Font.Color := clInfoBk;
           end;
        4 : begin
           ChildControl.Font.Style := [];
           ChildControl.Font.Color := clBlue;
           end;
        5 : begin
           ChildControl.Font.Style := [];
           ChildControl.Font.Color := clRed;
           end;
    end;
  end;
end;
procedure TForm1.Label_IsisWebClick(Sender: TObject);
var
   hi: Integer;
begin
hi:=ShellExecute(Form1.WindowHandle,Nil,'http://www.unesco.org/inftools',Nil,Nil, SW_SHOW);
end;

procedure TForm1.ImageBackgroundMouseMove(Sender: TObject;
  Shift: TShiftState; X, Y: Integer);
var
  I: Integer;
  ChildControl: TLabel;
begin
  for I:= 0 to Form1.ControlCount -1 do
  begin
    ChildControl := TLabel(Form1.Controls[I]);
    case ChildControl.HelpContext of
        0: begin
           ChildControl.Font.Style := [];
           ChildControl.Font.Color := clSkyBlue;
           end;
        2 : begin
           ChildControl.Font.Style := [];
           ChildControl.Font.Color := clInfoBk;
           end;
        4 : begin
           ChildControl.Font.Style := [];
           ChildControl.Font.Color := clBlue;
           end;
    end;
  end;

Panel_XML.visible:=false;
Panel_IDAMS.visible:=false;
Panel_GENISIS.visible:=false;
Panel_IsisDOC.visible:=false;
Panel_IDAMSDOC.visible:=false;
Panel_DataEx.Visible:=false;
Panel_IDIS.Visible:=false;
Panel_MARC.Visible:=false;
Panel_Winisis.Visible:=false;
end;

procedure TForm1.Label_IDAMSDocOtherClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\IDAMS\Guide_to_data_analysis\TOC.htm';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.Label_IDAMSDocENClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\IDAMS\WINIDAMS\English\Doc\pdf\ManualE.pdf';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.Label_IDAMSDocFRClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\IDAMS\WINIDAMS\French\Doc\pdf\ManualF.pdf';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.Label_IDAMSDocESClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\IDAMS\WINIDAMS\Spanish\Doc\pdf\ManualS.pdf';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.LabelIDAMSEngClick(Sender: TObject);
begin
filename:='\IDAMS\WINIDAMS\English\Install\WIDAMSR11E.exe';
WinExec(PChar(drv+filename), SW_SHOWNORMAL);
end;

procedure TForm1.LabelIDAMSFreClick(Sender: TObject);
begin
filename:='\IDAMS\WINIDAMS\French\Install\WIDAMSR11F.exe';
WinExec(PChar(drv+filename), SW_SHOWNORMAL);
end;

procedure TForm1.LabelIDAMSEspClick(Sender: TObject);
begin
filename:='\IDAMS\WINIDAMS\Spanish\Install\WIDAMSR11S.exe';
WinExec(PChar(drv+filename), SW_SHOWNORMAL);
end;

procedure TForm1.LabelIDISClick(Sender: TObject);
begin
Panel_Idis.Top:=240;
Panel_Idis.Left:=320;
Panel_Idis.Width:=313;
Panel_Idis.height:=137;
Panel_Idis.caption:='';
Panel_Idis.visible:=true;
end;

procedure TForm1.LabelIDISExeClick(Sender: TObject);
begin
filename:='\IDAMS\WinIDIS\Install\WIDISR1.exe';
WinExec(PChar(drv+filename), SW_SHOWNORMAL);
end;

procedure TForm1.LabelIDISGuideClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\IDAMS\WinIDIS\Doc\WinIDISUG.pdf';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.LabelIsisMarcClick(Sender: TObject);
begin
Panel_MARC.Top:=272;
Panel_MARC.Left:=8;
Panel_MARC.Width:=361;
Panel_MARC.height:=153;
Panel_MARC.caption:='';
Panel_MARC.visible:=true;
end;

procedure TForm1.LabelMarcInstallClick(Sender: TObject);
begin
filename:='\CDS-ISIS\isismarc\SetupIsisMarc11b.exe';
WinExec(PChar(drv+filename), SW_SHOWNORMAL);
end;

procedure TForm1.LabelMarcManualClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\CDS-ISIS\isismarc\doc';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.LabelGenisisWebClick(Sender: TObject);
begin
filename:='\CDS-ISIS\genisis\web\setup.exe';
WinExec(PChar(drv+filename), SW_SHOWNORMAL);
end;

procedure TForm1.LabelGenisisCDClick(Sender: TObject);
begin
filename:='\CDS-ISIS\genisis\cd\setup.exe';
WinExec(PChar(drv+filename), SW_SHOWNORMAL);
end;

procedure TForm1.LabelGenisisWebUMClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\CDS-ISIS\genisis\web\genisisweb.pdf';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.LabelGenisisCDUMClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\CDS-ISIS\genisis\cd\genisiscd.pdf';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.Label2709Click(Sender: TObject);
var
   hi: Integer;
begin
filename:='\CDS-ISIS\tools\impexp\ImpExp1008b.zip';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.LabelIsisAsciiClick(Sender: TObject);
begin
filename:='\CDS-ISIS\tools\isisascii\Setup.exe';
WinExec(PChar(drv+filename), SW_SHOWNORMAL);
end;

procedure TForm1.LabelHandbookENClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\CDS-ISIS\winisis\doc\english\whandbk.pdf';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.LabelIsisGuideENClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\CDS-ISIS\winisis\doc\english\winisis1_4New.pdf';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.LabelNetworkENClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\CDS-ISIS\winisis\doc\english\en_winisis_network.pdf';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.LabelWinisisNewClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\CDS-ISIS\winisis\doc\english\Wisis1_5_news.doc';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.LabelIsisDocFREClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\CDS-ISIS\winisis\doc\french';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.LabelIsisDocEspClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\CDS-ISIS\winisis\doc\spanish';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.LabelIsisDocRusClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\CDS-ISIS\winisis\doc\russian';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.LabelIsisDocCHIClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\CDS-ISIS\winisis\doc\chinese';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.LabelIsisMarc2Click(Sender: TObject);
begin
LabelIsisMarcClick(Sender);
end;

procedure TForm1.LabelIDIS2Click(Sender: TObject);
begin
LabelIDISClick(Sender);
end;

procedure TForm1.LabelWinisis15Click(Sender: TObject);
begin
filename:='\CDS-ISIS\winisis\install\wisis15.exe';
WinExec(PChar(drv+filename), SW_SHOWNORMAL);
end;

procedure TForm1.ButtonAcceptClick(Sender: TObject);
begin
ButtonAccept.Visible:=false;
ButtonDecline.Visible:=false;
MemoCopyright.Visible := False;
LabelInstructions.Visible := True;
LabelWinisis.Visible := True;
LabelGenisis.Visible := True;
LabelXML.Visible := True;
LabelDataExchange.Visible := True;
LabelIDAMS.Visible := True;
LabelIDIS.Visible := True;
LabelIDIS2.Visible := True;

LabelIsisMarc.Visible:=True;
LabelIsisMarc2.visible:=true;
end;

procedure TForm1.ButtonDeclineClick(Sender: TObject);
begin
Application.Terminate;
end;

procedure TForm1.WinisisMouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Integer);
var
  I: Integer;
  ChildControl: TLabel;
begin
  for I:= 0 to Panel_Winisis.ControlCount -1 do
  begin
    ChildControl := TLabel(Panel_Winisis.Controls[I]);
    case ChildControl.HelpContext of
        0: begin
           ChildControl.Font.Style := [];
           ChildControl.Font.Color := clBlack;
           end;
    end;
  end;
TLabel(Sender).Font.Color:=clBlue;
TLabel(Sender).Font.Style:=[fsBold];
end;

procedure TForm1.LabelJavaISISClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\CDS-ISIS\javaisis';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.LabelIsisRMClick(Sender: TObject);
var
   hi: Integer;
begin
filename:='\CDS-ISIS\winisis\doc\english\WINISIS15.pdf';
hi:=ShellExecute(Form1.WindowHandle,Nil,PChar(drv+filename),Nil,Nil, SW_SHOW);
end;

procedure TForm1.Label_XML2IsisClick(Sender: TObject);
begin
filename:='\CDS-ISIS\tools\xml2isis\XML2ISIS_Setup.exe';
WinExec(PChar(drv+filename), SW_SHOWNORMAL);
end;

procedure TForm1.Label_Isis2XMLClick(Sender: TObject);
begin
filename:='\CDS-ISIS\tools\isis2xml\isis2xml.exe';
WinExec(PChar(drv+filename), SW_SHOWNORMAL);
end;

end.


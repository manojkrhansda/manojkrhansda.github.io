@echo off
start "" "C:\Program Files (x86)\DOSBox-0.74-3\DOSBox.exe" ^

-c "mount c c:\isis" ^
-c "c:" ^
-c "cd isis" ^
-c "ISIS.EXE"
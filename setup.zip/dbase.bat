@echo off
start "" "C:\Program Files (x86)\DOSBox-0.74-3\DOSBox.exe" ^
@-fullscreen ^
-c "mount c c:\dbase" ^
-c "c:" ^
-c "cd dbase" ^
-c "DBASE.EXE"